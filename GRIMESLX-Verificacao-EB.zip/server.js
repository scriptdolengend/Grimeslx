require("dotenv").config();

const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const dbDir = path.join(__dirname, "data");
require("fs").mkdirSync(dbDir, { recursive: true });

const db = new Database(path.join(dbDir, "grimeslx.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT NOT NULL,
    discord_username TEXT NOT NULL,
    roblox_username TEXT NOT NULL,
    roblox_id TEXT NOT NULL,
    rank TEXT NOT NULL,
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'PENDENTE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TEXT,
    reviewed_by TEXT
  )
`);

const required = ["DISCORD_CLIENT_ID", "DISCORD_CLIENT_SECRET", "DISCORD_REDIRECT_URI", "SESSION_SECRET"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) console.warn("Configure as variaveis:", missing.join(", "));

app.set("trust proxy", 1);
app.use(express.json({ limit: "20kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dbDir }),
  secret: process.env.SESSION_SECRET || "configure-SESSION_SECRET-antes-de-publicar",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

app.use(express.static(path.join(__dirname, "public")));

function isLoggedIn(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Faça login pelo Discord primeiro." });
  next();
}
function isAdmin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Faça login pelo Discord." });
  const admins = (process.env.ADMIN_DISCORD_IDS || "").split(",").map(x => x.trim()).filter(Boolean);
  if (!admins.includes(req.session.user.id)) return res.status(403).json({ error: "Acesso restrito aos administradores." });
  next();
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "GRIMESLX" }));

app.get("/auth/discord", (req, res) => {
  if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_REDIRECT_URI) {
    return res.status(500).send("Configure DISCORD_CLIENT_ID e DISCORD_REDIRECT_URI no Render.");
  }
  const state = crypto.randomBytes(24).toString("hex");
  req.session.oauthState = state;
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_REDIRECT_URI,
    response_type: "code",
    scope: "identify",
    state
  });
  res.redirect("https://discord.com/oauth2/authorize?" + params.toString());
});

app.get("/auth/discord/callback", async (req, res) => {
  try {
    const { code, state, error } = req.query;
    if (error) return res.redirect("/?login=cancelado");
    if (!code || !state || state !== req.session.oauthState) return res.status(400).send("Login invalido. Tente novamente.");
    delete req.session.oauthState;

    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: process.env.DISCORD_REDIRECT_URI
      })
    });
    const token = await tokenResponse.json();
    if (!tokenResponse.ok || !token.access_token) {
      console.error("Falha OAuth Discord:", token);
      return res.status(400).send("Não foi possível autenticar com o Discord.");
    }

    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${token.access_token}` }
    });
    const user = await userResponse.json();
    if (!userResponse.ok) return res.status(400).send("Não foi possível obter sua conta Discord.");

    req.session.user = {
      id: user.id,
      username: user.global_name || user.username,
      avatar: user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : null
    };
    res.redirect("/");
  } catch (e) {
    console.error(e);
    res.status(500).send("Erro interno durante o login.");
  }
});

app.get("/api/me", (req, res) => {
  if (!req.session.user) return res.json({ loggedIn: false });
  const admins = (process.env.ADMIN_DISCORD_IDS || "").split(",").map(x => x.trim());
  res.json({ loggedIn: true, user: req.session.user, isAdmin: admins.includes(req.session.user.id) });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.json({ ok: true });
  });
});

app.post("/api/verifications", isLoggedIn, (req, res) => {
  const robloxUsername = String(req.body.robloxUsername || "").trim();
  const robloxId = String(req.body.robloxId || "").trim();
  const rank = String(req.body.rank || "").trim();
  const notes = String(req.body.notes || "").trim().slice(0, 500);

  if (robloxUsername.length < 3 || robloxUsername.length > 30 ||
      !/^\d{1,20}$/.test(robloxId) || rank.length < 2 || rank.length > 60) {
    return res.status(400).json({ error: "Confira o nick, o ID numérico do Roblox e a patente." });
  }

  const existing = db.prepare("SELECT id FROM verifications WHERE discord_id = ? AND status = 'PENDENTE'").get(req.session.user.id);
  if (existing) return res.status(409).json({ error: "Você já tem uma solicitação pendente." });

  const result = db.prepare(`
    INSERT INTO verifications (discord_id, discord_username, roblox_username, roblox_id, rank, notes)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(req.session.user.id, req.session.user.username, robloxUsername, robloxId, rank, notes);

  res.json({ ok: true, id: result.lastInsertRowid });
});

app.get("/api/my-verifications", isLoggedIn, (req, res) => {
  const rows = db.prepare(`
    SELECT id, roblox_username, roblox_id, rank, notes, status, created_at, reviewed_at
    FROM verifications WHERE discord_id = ? ORDER BY id DESC LIMIT 20
  `).all(req.session.user.id);
  res.json(rows);
});

app.get("/api/admin/verifications", isAdmin, (req, res) => {
  const rows = db.prepare("SELECT * FROM verifications ORDER BY CASE status WHEN 'PENDENTE' THEN 0 ELSE 1 END, id DESC LIMIT 300").all();
  res.json(rows);
});

app.post("/api/admin/verifications/:id/status", isAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = String(req.body.status || "");
  if (!Number.isInteger(id) || !["APROVADO", "REJEITADO"].includes(status)) {
    return res.status(400).json({ error: "Ação inválida." });
  }
  const result = db.prepare(`
    UPDATE verifications SET status = ?, reviewed_at = CURRENT_TIMESTAMP, reviewed_by = ?
    WHERE id = ? AND status = 'PENDENTE'
  `).run(status, req.session.user.username, id);
  if (!result.changes) return res.status(404).json({ error: "Solicitação não encontrada ou já analisada." });
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`GRIMESLX rodando na porta ${PORT}`));
