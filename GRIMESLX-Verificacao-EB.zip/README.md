# GRIMESLX — Verificação EB

Sistema web com login Discord OAuth2, formulário EB, histórico do usuário e painel administrativo.

## 1. Configurar o Discord

1. Abra https://discord.com/developers/applications e escolha sua aplicação.
2. Em OAuth2, adicione exatamente o endereço:
   `https://SEU-SITE.onrender.com/auth/discord/callback`
3. Copie o Client ID e o Client Secret. **Nunca coloque o Client Secret no HTML, JavaScript público ou GitHub.**

## 2. Publicar no GitHub + Render

1. Crie um repositório GitHub e envie todos os arquivos desta pasta.
2. No Render, crie um novo **Web Service** conectado ao repositório.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Configure as variáveis de ambiente:
   - `DISCORD_CLIENT_ID`: Client ID da aplicação
   - `DISCORD_CLIENT_SECRET`: Client Secret (somente no painel privado do Render)
   - `DISCORD_REDIRECT_URI`: `https://SEU-SITE.onrender.com/auth/discord/callback`
   - `SESSION_SECRET`: uma chave longa e aleatória
   - `ADMIN_DISCORD_IDS`: IDs numéricos dos administradores, separados por vírgula
   - `NODE_ENV`: `production`
6. No Discord Developer Portal, confirme que o Redirect URI é idêntico ao `DISCORD_REDIRECT_URI`.
7. Faça deploy.

## 3. Tornar-se administrador

Adicione o ID numérico da sua conta Discord em `ADMIN_DISCORD_IDS` no Render. Para mais administradores, separe os IDs por vírgula. O acesso ao painel é controlado pelo ID autenticado no Discord, não por uma senha compartilhada.

## 4. Banco de dados e hospedagem

O projeto usa SQLite em `data/grimeslx.sqlite`. Para manter os dados entre reinicializações e deploys, configure um disco persistente no Render e defina `DB_PATH` para um caminho dentro desse disco, por exemplo `/var/data/grimeslx.sqlite`. Crie o disco no Render antes de usar em produção. Sem disco persistente, dados locais podem ser perdidos em determinadas hospedagens/deploys.

## 5. Escopos e segurança

O login solicita apenas `identify`. O site não pede senha do Discord, token de bot nem permissões de servidor. Use HTTPS, mantenha os segredos privados e não compartilhe o `.env`.
