const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url, options={}) {
  const r = await fetch(url, { credentials:"same-origin", headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options });
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "Ocorreu um erro.");
  return data;
}
function show(el, yes=true){ el.classList.toggle("hidden", !yes); }
function statusLabel(s){return `<span class="status ${esc(s)}">${esc(s)}</span>`;}
async function loadMine(){
  const rows=await api("/api/my-verifications");
  $("#myRows").innerHTML=rows.length?rows.map(x=>`<div class="rowitem"><b>#${x.id} · ${esc(x.roblox_username)}</b><br>Patente: ${esc(x.rank)} · ID Roblox: ${esc(x.roblox_id)}<br>Status: ${statusLabel(x.status)}<br><small>${esc(x.created_at)}</small></div>`).join(""):"<p class='message'>Você ainda não enviou uma solicitação.</p>";
}
async function loadAdmin(){
  const rows=await api("/api/admin/verifications");
  $("#adminRows").innerHTML=rows.length?rows.map(x=>`<div class="rowitem"><b>#${x.id} · ${esc(x.roblox_username)}</b> — ${statusLabel(x.status)}<br>Discord: ${esc(x.discord_username)} (${esc(x.discord_id)})<br>Roblox ID: ${esc(x.roblox_id)} · Patente: ${esc(x.rank)}<br>Observações: ${esc(x.notes||"—")}<br><small>Enviado: ${esc(x.created_at)}</small>${x.status==="PENDENTE"?`<div class="actions"><button class="approve" onclick="review(${x.id},'APROVADO')">APROVAR</button><button class="reject" onclick="review(${x.id},'REJEITADO')">REJEITAR</button></div>`:""}</div>`).join(""):"<p>Nenhuma solicitação encontrada.</p>";
}
window.review=async(id,status)=>{try{await api(`/api/admin/verifications/${id}/status`,{method:"POST",body:JSON.stringify({status})});await loadAdmin();}catch(e){alert(e.message)}};
async function init(){
  const me=await api("/api/me");
  if(!me.loggedIn){show($("#loginArea"));return;}
  show($("#loginArea"),false);
  $("#userArea").innerHTML=`<div class="userline">${me.user.avatar?`<img class="avatar" src="${esc(me.user.avatar)}" alt="">`:""}<b>Conectado como ${esc(me.user.username)}</b><button class="logout" id="logout">SAIR</button></div>`;
  show($("#userArea"));
  $("#logout").onclick=async()=>{await api("/api/logout",{method:"POST"});location.reload()};
  show($("#formSection"));show($("#mySection"));await loadMine();
  if(me.isAdmin){show($("#adminSection"));await loadAdmin();}
}
$("#verificationForm").addEventListener("submit",async e=>{
  e.preventDefault();const form=new FormData(e.currentTarget);const body=Object.fromEntries(form.entries());
  $("#formMessage").textContent="Enviando...";
  try{await api("/api/verifications",{method:"POST",body:JSON.stringify(body)});$("#formMessage").textContent="Solicitação enviada para análise!";e.currentTarget.reset();await loadMine();}
  catch(err){$("#formMessage").textContent=err.message;}
});
init().catch(e=>console.error(e));
